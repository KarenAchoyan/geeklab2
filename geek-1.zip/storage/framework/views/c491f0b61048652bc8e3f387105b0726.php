<?php $__env->startSection('content'); ?>

    <div class="container">
        <h3 class="my-5">Հայտարարություններ</h3>
        <div class="add-post">
            <form action="<?php echo e(route('posts.add')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <textarea name="content" id="editor" cols="30" rows="10"></textarea>
                <button class="btn btn-success my-2">Add</button>
            </form>
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="posts-all">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center" >
                        <h4><?php echo e($post['user']['name']); ?></h4>
                        <?php if($post['user']['id']==Auth::id() || Auth::user()['role_id']==1): ?>
                            <a style="color: black" href="/posts/delete/<?php echo e($post['id']); ?>">
                                <i class="fa fa-close"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <?php echo $post->content; ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geek-1\resources\views/Auth/posts.blade.php ENDPATH**/ ?>