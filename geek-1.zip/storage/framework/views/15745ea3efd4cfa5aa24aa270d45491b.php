;
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Invite User</h1>

        <div class="add-form">
            <form action="<?php echo e(route('invite.add')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group mt-1">
                    <label for="">Email</label>
                    <input type="text" name="email" class="form-control">
                </div>
                <div class="form-group mt-1">
                    <label for="">Group</label>
                    <select name="group_id" id="" class="form-control">
                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group mt-2">
                    <button class="btn btn-success">Add</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geek-1\resources\views/teacher/invite.blade.php ENDPATH**/ ?>