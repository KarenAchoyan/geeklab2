<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="row">

            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <aside class="profile-nav alt">
                        <section class="card">
                            <div class="card-header user-header alt bg-dark">
                                <div class="media">
                                    <div class="media-body">
                                        <h2 class="text-light display-9 text-center"><?php echo e($key['group']['name']); ?></h2>
                                        <p class="text-center"><?php echo e($key['group']['user']['name']); ?></p>
                                    </div>
                                </div>
                            </div>
                            <ul class="list-group list-group-flush">

                                <li class="list-group-item">
                                    <a style="color: black" href="/student/lessons/<?php echo e($key['group']['id']); ?>"> <i class="fa fa-tasks"></i>
                                        Դասեր <span
                                            class="badge badge-danger pull-right"><?php echo e(count($key['group']['lessons'])); ?></span></a>
                                </li>
                                <li class="list-group-item">
                                    <a href="#" style="color: black"> <i class="fa fa-star"></i> Գնահատական <span
                                            class="badge badge-success pull-right">
                                             <?php
                                                 $homeworks = Auth::user()->homeworks;
                                                 $rating=0;
                                                 $count = 0;
                                                 foreach($homeworks as $homework){
                                                     if($homework['lesson']['group_id']==$key->group_id){
                                                          $rating+=$homework->rating;
                                                          $count++;
                                                     }
                                                 }
                                             ?>
                                            <?php if($count!=0): ?>
                                                <?php echo e($rating/$count); ?>

                                            <?php else: ?>
                                                0
                                            <?php endif; ?>
                                        </span></a>
                                </li>

                            </ul>

                        </section>
                    </aside>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geek-1\resources\views/student/my-groups.blade.php ENDPATH**/ ?>