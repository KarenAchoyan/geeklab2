<?php $__env->startSection('content'); ?>

    <div class="container">

        <table class="table">
            <tr>
                <th>Id</th>
                <th>Lesson Title</th>
                <th>Group</th>
                <th>Rating</th>
                <th>Delete</th>
                <th>Rating</th>
            </tr>
            <?php $__currentLoopData = $homeworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key->id); ?></td>
                    <td><?php echo e($key['lesson']['title']); ?></td>
                    <td><?php echo e($key['lesson']['group']['name']); ?></td>
                    <td><?php echo e($key['rating']); ?></td>
                    <td>
                        <a href="">
                            <button class="btn btn-danger">Ջնջել</button>
                        </a>
                    </td>
                    <td>
                        <button type="button" class="btn btn-success mb-1" data-toggle="modal"
                                data-target="#largeModal-<?php echo e($key->id); ?>">
                            Գնահատել
                        </button>
                        <div class="modal fade" id="largeModal-<?php echo e($key->id); ?>" tabindex="-1" role="dialog"
                             aria-labelledby="largeModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="largeModalLabel">Large Modal</h5>
                                        <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('homeworks.rating')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($key->id); ?>">
                                            <div class="my-2">
                                                <label for="">Գնահատական</label>
                                                <input type="text" placeholder="1-10" name="rating" class="form-control">
                                            </div>
                                            <div>
                                                <button class="btn btn-success">Գնահատել</button>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                            Cancel
                                        </button>
                                        <button type="button" class="btn btn-primary">Confirm</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geek-1\resources\views/teacher/homeworks.blade.php ENDPATH**/ ?>