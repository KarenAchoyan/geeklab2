;
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Add group</h1>

        <div class="add-form">
            <form action="<?php echo e(route('group.add')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group mt-1">
                    <label for="">Name</label>
                    <input type="text" name="name" class="form-control">
                </div>
                <div class="form-group mt-2">
                    <button class="btn btn-success">Add</button>
                </div>
            </form>
        </div>
        <div class="all-data">
            <table class="table">
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Delete</th>
                    <th>Edit</th>
                </tr>
                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key->id); ?></td>
                        <td><?php echo e($key->name); ?></td>
                        <td>
                            <a href="">
                                <button class="btn btn-danger">Delete</button>
                            </a>
                        </td>
                        <td>
                            <a href="">
                                <button class="btn btn-info">Edit</button>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geek-1\resources\views/teacher/group.blade.php ENDPATH**/ ?>