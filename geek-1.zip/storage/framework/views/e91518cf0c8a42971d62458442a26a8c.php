;
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Add group</h1>

        <div class="add-form">
            <form action="<?php echo e(route('group.add')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group mt-1">
                    <label for="">Name</label>
                    <input type="text" name="name" class="form-control">
                </div>
                <div class="form-group mt-2">
                    <button class="btn btn-success">Add</button>
                </div>
            </form>
        </div>
        <div class="all-data">
            <table class="table">
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Delete</th>
                    <th>Students</th>
                </tr>
                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key->id); ?></td>
                        <td><?php echo e($key->name); ?></td>
                        <td>
                            <a href="/teacher/group/delete/<?php echo e($key->id); ?>">
                                <button class="btn btn-danger">Delete</button>
                            </a>
                        </td>
                        <td>
                            <a href="#">
                                <button type="button" class="btn btn-success mb-1" data-toggle="modal"
                                        data-target="#largeModal-<?php echo e($key->id); ?>">
                                    Students
                                </button>
                                <div class="modal fade" id="largeModal-<?php echo e($key->id); ?>" tabindex="-1" role="dialog"
                                     aria-labelledby="largeModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="largeModalLabel">Large Modal</h5>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <table class="table">
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Phone</th>
                                                        <th>Email</th>
                                                        <th>Delete</th>
                                                    </tr>
                                                    <?php $__currentLoopData = $key->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($keys->name); ?></td>
                                                            <td><?php echo e($keys->phone); ?></td>
                                                            <td><?php echo e($keys->email); ?></td>
                                                            <td>
                                                                <?php
                                                                    $homeworks = $keys->homeworks;
                                                                    $rating=0;
                                                                    $count = 0;
                                                                    foreach($homeworks as $homework){
                                                                        if($homework['lesson']['group_id']==$key->id){
                                                                             $rating+=$homework->rating;
                                                                             $count++;
                                                                        }
                                                                    }
                                                                ?>
                                                                <?php if($count!=0): ?>
                                                                    <?php echo e($rating/$count); ?>

                                                                <?php else: ?>
                                                                    0
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <a href="/teacher/group/deleteStudent/<?php echo e($keys->id); ?>/<?php echo e($key->id); ?>">
                                                                    <button class="btn btn-danger">Delete</button>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </table>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                                    Cancel
                                                </button>
                                                <button type="button" class="btn btn-primary">Confirm</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geek-1\resources\views/teacher/group/group.blade.php ENDPATH**/ ?>