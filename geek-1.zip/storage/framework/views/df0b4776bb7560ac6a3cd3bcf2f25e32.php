<?php $__env->startSection('content'); ?>

    <div>
        <div class="d-flex justify-content-center">
            <div class="col-xs-6 col-sm-6">
                <div class="card">
                    <div class="card-header">
                        <strong>Անձնական տվյալներ</strong>
                    </div>
                    <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-body card-block">
                            <div class="form-group">
                                <label class=" form-control-label">Հեռախոսահամար</label>
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-phone"></i></div>
                                    <input class="form-control" name="phone" value="<?php echo e(Auth::user()['phone']); ?>">
                                </div>
                                <small class="form-text text-muted">ex. (094) 777777</small>
                            </div>
                            <div class="form-group">
                                <label class=" form-control-label">Էլ-հասցե</label>
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-envelope"></i></div>
                                    <input class="form-control" disabled name="email" value="<?php echo e(Auth::user()['email']); ?>">
                                </div>
                                <small class="form-text text-muted">ex. info@test.am</small>
                            </div>
                            <div class="form-group">
                                <label class=" form-control-label">Պրոֆիլի նկար</label>
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user"></i></div>
                                    <input class="form-control" type="file" name="file" value="<?php echo e(Auth::user()['email']); ?>">

                                </div>
                                <div class="my-2">
                                    <?php if(Auth::user()['avatar']!=null): ?>
                                        <img src="<?php echo e(asset('storage/'.Auth::user()['avatar'])); ?>" style="width:150px" alt="">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-info">Փոփոխել</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geek-1\resources\views/auth/profile.blade.php ENDPATH**/ ?>