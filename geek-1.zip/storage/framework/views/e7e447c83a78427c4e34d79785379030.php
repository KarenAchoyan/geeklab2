<?php $__env->startSection('content'); ?>

    <div class="container">

        <table class="table">
            <tr>
                <th>Id</th>
                <th>Lesson Title</th>
                <th>Group</th>
                <th>Rating</th>
            </tr>
            <?php $__currentLoopData = $homeworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key->id); ?></td>
                    <td><?php echo e($key['lesson']['title']); ?></td>
                    <td><?php echo e($key['lesson']['group']['name']); ?></td>
                    <td><?php echo e($key['rating']); ?></td>





                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geek-1\resources\views/student/my-homeworks.blade.php ENDPATH**/ ?>